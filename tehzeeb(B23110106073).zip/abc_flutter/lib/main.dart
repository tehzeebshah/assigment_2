import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BMI Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: BmiCalculator(),
    );
  }
}

class BmiCalculator extends StatefulWidget {
  @override
  _BmiCalculatorState createState() => _BmiCalculatorState();
}

class _BmiCalculatorState extends State<BmiCalculator> {
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  double _bmi = 0;
  String _bmiCategory = '';

  void _calculateBmi() {
    if (_heightController.text.isEmpty || _weightController.text.isEmpty) {
      _showErrorDialog('Please enter both height and weight');
      return;
    }

    try {
      double height = double.parse(_heightController.text); // height in meters
      double weight = double.parse(_weightController.text); // weight in kilograms
      _bmi = weight / (height * height);
      _bmiCategory = _getBmiCategory(_bmi);
      setState(() {});
    } catch (e) {
      _showErrorDialog('Invalid input');
    }
  }

  String _getBmiCategory(double bmi) {
    if (bmi < 18.5) {
      return 'Underweight';
    } else if (bmi < 25) {
      return 'Normal weight';
    } else if (bmi < 30) {
      return 'Overweight';
    } else {
      return 'Obesity';
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _reset() {
    _heightController.clear();
    _weightController.clear();
    _bmi = 0;
    _bmiCategory = '';
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Calculator'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                controller: _heightController,
                decoration: InputDecoration(
                  labelText: 'Height (meters)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20),
              TextField(
                controller: _weightController,
                decoration: InputDecoration(
                  labelText: 'Weight (kilograms)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _calculateBmi,
                child: Text('Calculate BMI'),
              ),
              SizedBox(height: 20),
              Text(
                _bmi == 0 ? '' : 'BMI: ${_bmi.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 24),
              ),
              Text(
                _bmiCategory,
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _reset,
                child: Text('Reset'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
